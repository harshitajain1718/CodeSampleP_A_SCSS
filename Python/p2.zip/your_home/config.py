import os

class Config(object):
	# Sets a secreat key that is used for secturity against CSRF(Cross Site Request Forgery)
	SECRET_KEY = os.environ.get('SECRET_KEY') or 'nothing'

	# Database Configuration
	MYSQL_HOST = '127.0.0.1'
	MYSQL_USER = 'root'
	MYSQL_PASSWORD = ''
	MYSQL_DB = 'your_home'

	#put upload folder path here
	#UPLOAD_FOLDER = ''