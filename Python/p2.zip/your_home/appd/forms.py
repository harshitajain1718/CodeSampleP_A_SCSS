from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, BooleanField, SubmitField, RadioField
from wtforms.validators import ValidationError, InputRequired, Email, Length, EqualTo, Regexp
from flask_wtf.file import FileField, FileAllowed, FileRequired


class LoginForm(FlaskForm):
	email = StringField('Email', validators=[InputRequired(), Email(), Length(max=60)])
	password = PasswordField('Password', validators=[InputRequired(), Length(min=5, max=32)])
	remember_me = BooleanField('Remember Me')
	submit = SubmitField('Log In')

class RegistrationForm(FlaskForm):
	username = StringField('Username', validators=[InputRequired(), Length(max=50)])
	email = StringField('Email', validators=[InputRequired(), Email(), Length(max=60)])
	password = PasswordField('Password', validators=[InputRequired(), Length(min=5, max=32)])
	password2 = PasswordField('Confirm Password', validators=[InputRequired(), Length(min=5, max=32), EqualTo('password')])
	gender = RadioField('Gender', choices=[('M','Male'), ('F','Female')], default='M')
	submit = SubmitField('Register')

class PropertyForm(FlaskForm):
	propertyname = StringField('Property Name', validators=[InputRequired(), Length(max=50)])
	address = StringField('Address', validators=[InputRequired(), Length(max=60)])
	pincode = StringField('Pincode', validators=[InputRequired(), Length(max=6), Regexp('^[1-9][0-9]{5}$')])
	photo = FileField('Upload Photo: ', validators=[FileRequired(), FileAllowed(['jpg', 'png'], 'Images Only') ])
	submit = SubmitField('Upload')

class UpdateForm(FlaskForm):
	username = StringField('Username', validators=[InputRequired(), Length(max=50)])
	#email = StringField('Email', validators=[DataRequired(), Email(), Length(max=60)])
	password = PasswordField('Password', validators=[InputRequired(), Length(min=5, max=32)])
	password2 = PasswordField('Confirm Password', validators=[InputRequired(), Length(min=5, max=32), EqualTo('password')])
	gender = RadioField('Gender', choices=[('M','Male'), ('F','Female'), ('O','Other')], default='M')
	propertyname = StringField('Property Name', validators=[InputRequired(), Length(max=50)])
	address = StringField('Address', validators=[InputRequired(), Length(max=60)])
	pincode = StringField('Pincode', validators=[InputRequired(), Length(max=6), Regexp('^[1-9][0-9]{5}$')])
	photo = FileField('Upload Photo: ', validators=[FileRequired(), FileAllowed(['jpg', 'png'], 'Images Only') ])
	submit = SubmitField('Edit')
