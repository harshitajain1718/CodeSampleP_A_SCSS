from flask import render_template, flash, request, redirect, session, send_from_directory, jsonify
from appd import app, mysql
from appd.forms import LoginForm, RegistrationForm, PropertyForm, UpdateForm
from werkzeug.utils import secure_filename
from passlib.hash import sha256_crypt

@app.route('/')
@app.route('/index')
def index():
	return redirect('/login')

@app.route('/login', methods=['GET', 'POST'])
def login():
	form=LoginForm()
	if form.validate_on_submit():
		cur = mysql.connection.cursor()
		emaildata = cur.execute("SELECT password FROM users WHERE email= %s", [form.email.data])
		if emaildata>0:
			password = ''.join(cur.fetchone())
			if sha256_crypt.verify(form.password.data, password)>0:
				flash('Login requested for email {}, remember_me={}'.format(form.email.data, form.remember_me.data))
				session['email'] = form.email.data
				return redirect('/property')
			else:
				flash ("Invalid Credentials!!")
		else:
			flash ("Invalid Credentials!!")
	return render_template('login.html', title='Log In', form=form)

@app.route('/register', methods=['GET', 'POST'])
def register():
	form2=RegistrationForm()
	if form2.validate_on_submit():
		cur = mysql.connection.cursor()
		emaildata = cur.execute("SELECT * FROM users WHERE email= %s", [form2.email.data])
		if int(emaildata)>0:
			flash ("That email is already used, try another one!!")
			#return render_template('register.html', title='Register', form=form)
			#return jsonify(status='not ok')
		else:
			password = sha256_crypt.encrypt(form2.password.data)
			cur.execute("INSERT INTO users (username, email, password, gender) VALUES (%s, %s, %s, %s)", (form2.username.data, form2.email.data, password, form2.gender.data))
			mysql.connection.commit()
			cur.close()
			flash('Registration Successful')
			#return redirect('/login')
			return jsonify(status='ok')
	return render_template('register.html', form2=form2)

@app.route('/displayregister')
def display_register():
	form2=RegistrationForm();
	return render_template('register.html', form2=form2)

@app.route('/property', methods=['GET', 'POST'])
def property():
	if 'email' in session:
		email = session['email']
		form=PropertyForm()
		if form.validate_on_submit():
			p=form.photo.data
			photoname=secure_filename(p.filename)
			p.save('uploads/'+photoname)
			cur = mysql.connection.cursor()
			cur.execute("INSERT INTO property (email, property_name, address, pincode, photo_name) VALUES (%s, %s, %s, %s, %s)", (email, form.propertyname.data, form.address.data, form.pincode.data, photoname))
			mysql.connection.commit()
			cur.close()
			return redirect('/account')
		return render_template('property.html', title='Property', form=form)
	else:
		flash("You need to Login to see this content")
		return render_template('base.html')

@app.route('/account', methods=['GET', 'POST'])
def account():
	if 'email' in session:
		email = session['email']
		cur = mysql.connection.cursor()
		#cur.execute("SELECT users.*, property.* FROM users NATURAL JOIN property WHERE email=%s",(email))
		cur.execute("SELECT * FROM users WHERE email= %s", [email])
		userdata = cur.fetchall()
		cur.execute("SELECT * FROM property WHERE email= %s", [email])
		propertydata = cur.fetchall()
		cur.close()
		return render_template('display.html', title='Account', data1=userdata, data2=propertydata)
	else:
		flash("You need to Login to see this content")
		return render_template('base.html')

@app.route('/uploads/<photoname>')
def send_image(photoname):
	#find out how to do with path join and short path
	return send_from_directory('/home/brijesh/your_home/uploads/', photoname, as_attachment=True)

@app.route('/logout')
def logout():
	if 'email' in session:
		session.pop('email',None)
		flash('You have successfully logged out!')
		return redirect('/login')
	else:
		flash("You need to Login First")
		return render_template('base.html')

@app.route('/update', methods=['GET','POST'])
def update():
	if 'email' in session:
		email = session['email']
		cur = mysql.connection.cursor()
		#cur.execute("SELECT * FROM users WHERE email= %s", [email])
		#userdata = cur.fetchall()
		form=UpdateForm()
		#form.populate_obj(userdata)
		if form.validate_on_submit():
			p=form.photo.data
			photoname=secure_filename(p.filename)
			p.save('uploads/'+photoname)
			password = sha256_crypt.encrypt(form.password.data)
			cur.execute("UPDATE users SET username=%s, password=%s, gender=%s WHERE email=%s", (form.username.data, password, form.gender.data, email))
			cur.execute("SET FOREIGN_KEY_CHECKS=0")
			cur.execute("UPDATE property SET property_name=%s, address=%s, pincode=%s WHERE email=%s", (form.propertyname.data, form.address.data, form.pincode.data, email))
			cur.execute("SET FOREIGN_KEY_CHECKS=1")
			mysql.connection.commit()
			cur.close()
			return redirect('/account')
		return render_template('update.html', title='Update', form=form)
	else:
		flash("You need to Login to see this content")
		return render_template('base.html')

@app.route('/delete')
def delete():
	if 'email' in session:
		email = session['email']
		cur = mysql.connection.cursor()
		cur.execute("DELETE FROM users WHERE email=%s", [email])
		mysql.connection.commit()
		cur.close()
		session.pop('email', None)
		return redirect('/login')
	else:
		flash("You need to Login to see this content")
		return render_template('base.html')

@app.route('/home')
def home():
	return "HELLO!"