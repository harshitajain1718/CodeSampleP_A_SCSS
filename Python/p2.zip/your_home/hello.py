from flask import Flask
# '__name__'predefined variable, which is set to the name of the module in which it is used.		
app = Flask(__name__)

@app.route('/')			# binds a function to URL - decorator
def hello_world():
	return 'Hello, World!'

# Makes debug and running available to devices in your network, default 'localhost:5000'
#if __name__ == '__main__':
	#app.debug = True    
	#app.run(host = '192.168.1.171',port=5005) 
