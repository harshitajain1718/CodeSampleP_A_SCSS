from django.apps import AppConfig


class PostmanagerConfig(AppConfig):
    name = 'postmanager'
