from django.apps import AppConfig


class ProfilemanagerConfig(AppConfig):
    name = 'profilemanager'
