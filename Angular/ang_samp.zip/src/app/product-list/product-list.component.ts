import { Component, OnInit } from '@angular/core';
import { DashboardService } from '../services/dashboard.service';
import { ActivatedRoute, Router } from "@angular/router";


@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.scss']
})
export class ProductListComponent implements OnInit {
  bannerList = [
    { banner_image: "assets/img/slide-01.jpg" },
    { banner_image: "assets/img/slide-02.jpg" },
    { banner_image: "assets/img/slide-01.jpg" }
  ];
  title = "Product List";
  desc = "Lorem ipsum consectetur adipiscing<br>viverra honcus suscipit.";
  productList = [];

  constructor(
    private dashboardService: DashboardService,
    private router: Router,

  ) {}

  ngOnInit() {
    this.dashboardService.getCategoryList().subscribe((res) => {
      if (res["success"] && res["insuranceData"].length > 0) {
        this.productList = [...res["insuranceData"]];
      }
    }, (err) => {
      console.log(err)
    })
  }

  go(data){
    let name = data.insurance_title.replace(/ /g, '-');
    let encid = btoa(data.id);
    this.router.navigateByUrl(`product-detail/${name}/${encid}`)
  }

  insur_details(data){
    
    let name = data.insurance_title.replace(/ /g, '-');
    let encid = btoa(data.id);
    this.router.navigateByUrl(`insurance/${name}/${encid}`)
  }

  PressCarouselOptions = {
    margin: 30,
    nav: true,
    navText: [
      "<div class='nav-btn prev-slide'></div>",
      "<div class='nav-btn next-slide'></div>"
    ],
    responsiveClass: true,
    dots: false,
    responsive: {
      320: {
        items: 1,
        nav: true
      },
      768: {
        items: 2,
        nav: true
      },
      992: {
        items: 3,
        nav: true,
        loop: true
      }
    }
  };

}
