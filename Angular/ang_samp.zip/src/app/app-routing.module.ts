import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from  './home/home.component';
import { AboutComponent } from  './about/about.component';
import { ContactComponent } from './contact/contact.component';
import { PressComponent } from './press/press.component';
import { PressDetailComponent } from './press-detail/press-detail.component';
import { QuestionsComponent } from './questions/questions.component';
import { ProductListComponent } from './product-list/product-list.component';
import { InsuranceDetailComponent } from './insurance-detail/insurance-detail.component';
import { ProductDetailComponent } from './product-detail/product-detail.component';
import { FAQComponent } from './faq/faq.component';


const routes: Routes = [
  {
    path: "",
    pathMatch: "full",
    redirectTo: "/home"
  },
  {
    path: 'home', component: HomeComponent
  }, {
    path: 'about', component: AboutComponent
  }, {
    path: 'contact', component: ContactComponent
  }, {
    path: 'press', component: PressComponent
  }, {
    path: 'faq', component: FAQComponent
  }, {
    path: 'press-detail/:name/:id', component: PressDetailComponent
  }, {
    path: 'questions/:id', component: QuestionsComponent
  }, {
    path: 'product-list', component: ProductListComponent
  }, {
    path: 'insurance/:name/:id', component: InsuranceDetailComponent
  }, {
    path: 'product-detail/:name/:id', component: ProductDetailComponent
  }, {
    path: '**', redirectTo: '/home'
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes, {
    scrollPositionRestoration: 'enabled'
  })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
