import { Component, OnInit } from "@angular/core";
import { FormBuilder, Validators } from "@angular/forms";
import { ActivatedRoute, Router } from "@angular/router";
import { DashboardService } from "../services/dashboard.service";

@Component({
  selector: "app-demo",
  templateUrl: "./insurance-detail.component.html",
  styleUrls: ["./insurance-detail.component.scss"]
})
export class InsuranceDetailComponent implements OnInit {
  bannerList = [
    { banner_image: "assets/img/slide-01.jpg" },
    { banner_image: "assets/img/slide-02.jpg" },
    { banner_image: "assets/img/slide-01.jpg" }
  ];
  title;;
  desc;
  insurance_id: any;
  completed = false;

  categories: any = [];

  constructor(
    private dashboardService: DashboardService,
    private fb: FormBuilder,
    private route: ActivatedRoute,
    private r: Router
  ) {}

  questionForm = this.fb.group({});

  currentTab = 0;
  submitted = false;
  allTabs = [];
  actualProgress;
  progress;
  iTitle;
  options = ["Yes", "No"];
  formValues = [];

  ngOnInit() {
    let idd = this.route.snapshot.params["id"];
    this.insurance_id = atob(idd);
    this.dashboardService.getInsuranceDetails(this.insurance_id).subscribe(
      res => {
        if (res["success"] && res["insuranceData"] &&
          res["insuranceData"]["categories"] && res["insuranceData"]["categories"].length > 0) {
            this.title = res["insuranceData"]["insurance_title"];
            this.desc = res["insuranceData"]["short_description"];
            this.iTitle = res["insuranceData"].insurance_title;
            this.categories = res["insuranceData"]["categories"];
            for (var i = 0; i < this.categories.length; i++) {
              this.allTabs.push(false);
            }
            this.actualProgress = Math.round(100 / (this.allTabs.length + 1));
            this.progress = this.actualProgress;
            for (let i = 0; i < this.categories.length; i++) {
              this.categories[i]["questions"].map((x, ind) => {
                if(x.question_title) {
                  this.formValues.push(x.question_title + i + ind);
                  this.questionForm.addControl(
                    x.question_title + i + ind,
                    this.fb.control("", Validators.required)
                  );
                } else {
                  console.log('No')
                }
              });
            }
            if (this.categories.length > 0) {
              setTimeout(() => {
                this.showTab(this.currentTab);
              }, 100);
            }
          } else {
            alert('No details exists for this insurance')
            this.r.navigateByUrl("/home");
          }
      },
      err => {
        console.log(err);
        this.r.navigateByUrl('/home');
      }
    );
  }

  showTab(n) {
    // console.log('CURRENT TAB ', n)
    var x = document.getElementsByClassName("tab");
    x[n]["style"].display = "block";
    //... and fix the Previous/Next buttons:
    if (n == 0) {
      document.getElementById("prevBtn").style.display = "none";
    } else {
      document.getElementById("prevBtn").style.display = "inline";
    }
    if (n == x.length - 1) {
      document.getElementById("nextBtn").innerHTML = "Submit";
    } else {
      document.getElementById("nextBtn").innerHTML = "Next";
    }
  }

  seePro(arr) {
    let oldArr = arr.filter(x => {
      return x == true;
    });
    if (oldArr.length == arr.length) {
      this.progress = "100";
    } else {
      this.progress = Math.round(this.actualProgress * (oldArr.length + 1));
    }
  }

  nextPrev(n) {
    var x = document.getElementsByClassName("tab");
    if (n == 1) {
      this.allTabs[this.currentTab] = true;
      if (!this.validate()) return true;
      this.seePro(this.allTabs);
    }
    this.submitted = false;
    x[this.currentTab]["style"].display = "none";
    this.currentTab = this.currentTab + n;
    if (n == -1) {
      this.allTabs[this.currentTab] = false;
      this.seePro(this.allTabs);
    }
    if (this.currentTab >= x.length) {
      // ... the form gets submitted:
      document.getElementById("nextBtn").style.display = "none";
      document.getElementById("prevBtn").style.display = "none";
      this.questionForm.reset();
      this.completed = true;
      return false;
    }
    this.showTab(this.currentTab);
  }

  validate() {
    this.submitted = true;
    let i;
    let x = document.getElementsByClassName("tab");
    let y = x[this.currentTab].getElementsByTagName("input");
    for (i = 0; i < y.length; i++) {
      // console.log(y[i]);
      if (this.questionForm.controls[y[i].name].value == "") {
        // console.log("All fields are necessary");
        return false;
      }
    }
    this.allTabs[this.currentTab] = true;
    return true;
  }

  get f() {
    return this.questionForm.controls;
  }

  PressCarouselOptions = {
    margin: 30,
    nav: true,
    navText: [
      "<div class='nav-btn prev-slide'></div>",
      "<div class='nav-btn next-slide'></div>"
    ],
    responsiveClass: true,
    dots: false,
    responsive: {
      320: {
        items: 1,
        nav: true
      },
      768: {
        items: 2,
        nav: true
      },
      992: {
        items: 3,
        nav: true,
        loop: true
      }
    }
  };
}
