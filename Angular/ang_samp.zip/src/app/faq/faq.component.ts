import { Component, OnInit } from '@angular/core';
import { DashboardService } from '../services/dashboard.service';


@Component({
  selector: 'app-faq',
  templateUrl: './faq.component.html',
  styleUrls: ['./faq.component.scss']
})
export class FAQComponent implements OnInit {
  bannerList = [
    { banner_image: "assets/img/slide-01.jpg" },
    { banner_image: "assets/img/slide-02.jpg" },
    { banner_image: "assets/img/slide-01.jpg" }
  ];
  title = "FAQ";
  desc = "Lorem ipsum consectetur adipiscing<br>viverra honcus suscipit.";
  FAQlist=[];
  constructor(
    private dashboardService: DashboardService
  ) { }

  ngOnInit() {
    this.dashboardService.getFAQList().subscribe(
      res => {
        if (res["success"] && res["FAQSDetails"].length > 0) {
          this.FAQlist = [...res["FAQSDetails"]];          
        }
      },
      err => {
        console.log(err);
      }
    );
    
  }

}
