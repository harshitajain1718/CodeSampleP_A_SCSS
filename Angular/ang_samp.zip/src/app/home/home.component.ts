import { Component, OnInit } from '@angular/core';
import { DashboardService } from '../services/dashboard.service';
import { OwlOptions } from "ngx-owl-carousel-o";
import { ActivatedRoute, Router } from "@angular/router";

@Component({
  selector: "app-home",
  templateUrl: "./home.component.html",
  styleUrls: ["./home.component.scss"]
})
export class HomeComponent implements OnInit {
  bannerList = [];
  categoryList = [];
  quoteList = [];
  partnerList = [];
  count: number;

  constructor(
    private dashboardService: DashboardService,
    private router: Router
    ) {}

  ngOnInit() {
    this.dashboardService.getBannerList().subscribe(
      res => {
        if (res["success"] && res["bannerData"].length > 0) {
          this.bannerList = [...res["bannerData"]];
        }
      },
      err => {
        console.log(err);
      }
    );

    this.dashboardService.getCategoryList().subscribe(
      res => {
        if (res["success"] && res["insuranceData"].length > 0) {
          this.categoryList = [...res["insuranceData"]];
          // Needed for assigning items dynamically
          this.count =
            this.categoryList.length >= 5 ? 5 : this.categoryList.length;
          // this.carouselOptions.responsive[1250].items = this.count;
        }
      },
      err => {
        console.log(err);
      }
    );

    this.dashboardService.getQuotes().subscribe(
      res => {
        if (res["success"] && res["sectionData"].length > 0) {
          this.quoteList = [...res["sectionData"]];
          for (var i = 0; i < this.quoteList.length; i++) {
            this.quoteList[0].icon = "fa fa-users";
            this.quoteList[1].icon = "fa fa-quote-left";
            this.quoteList[2].icon = "fa fa-handshake-o";
          }
        }
      },
      err => {
        console.log(err);
      }
    );

    this.dashboardService.getParterList().subscribe(
      res => {
        if (res["success"] && res["PartnerData"].length > 0) {
          this.partnerList = [...res["PartnerData"]];
        }
      },
      err => {
        console.log(err);
      }
    );
  }

  go(data){
    let name = data.insurance_title.replace(/ /g, '-');
    let encid = btoa(data.id);
    this.router.navigateByUrl(`product-detail/${name}/${encid}`)
  }

  insur_details(data){
    
    let name = data.insurance_title.replace(/ /g, '-');
    let encid = btoa(data.id);
    this.router.navigateByUrl(`insurance/${name}/${encid}`)
  }

  carouselOptions1 : OwlOptions = {
    margin: 10,
    nav: true,
    navText: ["<div class='nav-btn prev-slide'></div>", "<div class='nav-btn next-slide'></div>"],
    // responsiveClass: true,
    dots: false,
    loop: true,
    responsive: {
      0: {
        items: 1
      },
      400: {
        items: 2
      },
      740: {
        items: 3
      },
      940: {
        items: 5
      }
    },
  }

  carouselOptions108 = {
    margin: 10,
    nav: true,
    navText: ["<div class='nav-btn prev-slide'></div>", "<div class='nav-btn next-slide'></div>"],
    responsiveClass: true,
    dots: false,
    loop: true,
    responsive: {
      320: {
        items: 1,
        nav: true
      },
      600: {
        items: 2,
        nav: true
      },
      1024: {
        items: 3,
        nav: true
      },
      1250: {
        items: 5,
        nav: true
      }
    }
  }

}
