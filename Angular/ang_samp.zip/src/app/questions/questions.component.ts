import { Component, OnInit } from "@angular/core";
import { FormBuilder, Validators } from "@angular/forms";

@Component({
  selector: "app-questions",
  templateUrl: "./questions.component.html",
  styleUrls: ["./questions.component.scss"]
})
export class QuestionsComponent implements OnInit {
  bannerList = [
    { banner_image: "assets/img/slide-01.jpg" },
    { banner_image: "assets/img/slide-02.jpg" },
    { banner_image: "assets/img/slide-01.jpg" }
  ];
  title = "D&O Director and Officers";
  desc =
    "Lorem ipsum consectetur adipiscing elitroin viverra<br>vulputate honcus suscipit.";

  constructor(private fb: FormBuilder) {}

  questionForm = this.fb.group({
    Radios1: ["", Validators.required],
    Radios2: ["", Validators.required],
    Radios3: ["", Validators.required],
    Radios4: ["", Validators.required],
    Radios5: ["", Validators.required],
    loca_name: ["", Validators.required],
    business_name: ["", Validators.required],
    business_postcode: ["", Validators.required],
    business_contact: ["", Validators.required]
  });

  currentTab = 0;
  submitted = false;
  allTabs = [false, false, false, false, false];
  actualProgress = Math.round(100 / (this.allTabs.length + 1));
  progress;

  ngOnInit() {
    this.showTab(this.currentTab);
    this.progress = this.actualProgress;
    // console.log(this.progress)
  }

  showTab(n) {
    var x = document.getElementsByClassName("tab");
    console.log(x)
    x[n]["style"].display = "block";
    //... and fix the Previous/Next buttons:
    if (n == 0) {
      document.getElementById("prevBtn").style.display = "none";
    } else {
      document.getElementById("prevBtn").style.display = "inline";
    }
    if (n == x.length - 1) {
      document.getElementById("nextBtn").innerHTML = "Submit";
    } else {
      document.getElementById("nextBtn").innerHTML = "Next";
    }
  }

  seePro(arr) {
    let oldArr = arr.filter(x => { return x == true });
    if (oldArr.length == 5) {
      this.progress = "100";
    } else {
      this.progress = this.actualProgress * (oldArr.length + 1);
    }
  }

  nextPrev(n) {
    var x = document.getElementsByClassName("tab");
    if (n == 1) {
      this.allTabs[this.currentTab] = true;
      this.seePro(this.allTabs)
      if (!this.validate()) return true;
    }
    this.submitted = false;
    x[this.currentTab]["style"].display = "none";
    this.currentTab = this.currentTab + n;

    if(n == -1) {
      this.allTabs[this.currentTab] = false;
      this.seePro(this.allTabs);
    }

    if (this.currentTab >= x.length) {
      // ... the form gets submitted:
      document.getElementById("nextBtn").style.display = "none";
      document.getElementById("prevBtn").style.display = "none";
      this.questionForm.reset();
      return false;
    }
    this.showTab(this.currentTab);
  }

  validate() {
    this.submitted = true;
    let i;
    let x = document.getElementsByClassName("tab");
    let y = x[this.currentTab].getElementsByTagName("input");
    for (i = 0; i < y.length; i++) {
      if (this.questionForm.controls[y[i].name].value == "") {
        // console.log("All fields are necessary");
        return false;
      }
    }
    // this.allTabs[this.currentTab] = true;
    return true;
  }

  get f() {
    return this.questionForm.controls;
  }

  PressCarouselOptions = {
    margin: 30,
    nav: true,
    navText: [
      "<div class='nav-btn prev-slide'></div>",
      "<div class='nav-btn next-slide'></div>"
    ],
    responsiveClass: true,
    dots: false,
    responsive: {
      320: {
        items: 1,
        nav: true
      },
      768: {
        items: 2,
        nav: true
      },
      992: {
        items: 3,
        nav: true,
        loop: true
      }
    }
  };
}
