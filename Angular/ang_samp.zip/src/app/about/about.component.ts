import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-about',
  templateUrl: './about.component.html',
  styleUrls: ['./about.component.scss']
})
export class AboutComponent implements OnInit {

  bannerList = [
    {banner_image: 'assets/img/slide-01.jpg'},
    {banner_image: 'assets/img/slide-02.jpg'},
    {banner_image: 'assets/img/slide-01.jpg'}
  ]
  title = "Who we are";
  desc = "Lorem ipsum consectetur adipiscing elitroin viverra<br>vulputate honcus suscipit.";

  constructor() { }

  ngOnInit() {
  }

}
