import { Component, OnInit } from '@angular/core';
import { Location } from "@angular/common";
import { DashboardService } from '../services/dashboard.service';
import { ActivatedRoute, Router } from "@angular/router";
import { OwlOptions } from "ngx-owl-carousel-o";


@Component({
  selector: "app-press",
  templateUrl: "./press.component.html",
  styleUrls: ["./press.component.scss"]
})
export class PressComponent implements OnInit {
  bannerList = [
    { banner_image: "assets/img/slide-01.jpg" },
    { banner_image: "assets/img/slide-02.jpg" },
    { banner_image: "assets/img/slide-01.jpg" }
  ];
  title = "Press";
  desc = "Lorem ipsum consectetur adipiscing<br>viverra honcus suscipit.";
  pressList = [];
  release_PL = [];
  news_PL = [];

  constructor(
    private dashboardService: DashboardService,
    private router: Router,
    private loc: Location
  ) {}

  ngOnInit() {

    this.dashboardService.getPressList().subscribe((res) => {
      if (res["success"] && res["pressData"].length > 0) {
        this.pressList = [...res["pressData"]];
        // this.pressList.splice(3, 1)
        this.release_PL = this.pressList.filter((x) =>{
          return x.press_type == '1';
        });
        this.news_PL = this.pressList.filter((x) =>{
          return x.press_type == '2';
        });
      }
    }, (err) => {
      console.log(err)
    })
  }

  go(data){
    let name = data.press_title.replace(/ /g, '-');
    let encid = btoa(data.id);
    this.router.navigateByUrl(`press-detail/${name}/${encid}`)
  }
  PressCarouselOptions : OwlOptions = {
    margin: 30,
    nav: true,
    navText: ["<div class='nav-btn prev-slide'></div>", "<div class='nav-btn next-slide'></div>"],
    // responsiveClass: true,
    dots: false,
    loop: true,
    responsive: {
      0: {
        items: 1
      },
      400: {
        items: 2
      },
      740: {
        items: 3
      },
      940: {
        items: 3
      }
    },

  };
}
