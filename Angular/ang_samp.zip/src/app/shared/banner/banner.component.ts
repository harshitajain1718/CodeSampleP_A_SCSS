import { Component, OnInit, Input, ViewChild } from '@angular/core';
import actividades_list from "../../../assets/docs/actividades_list.json";
import { DashboardService } from "../../services/dashboard.service";
import { Observable, Subject } from 'rxjs';
import { debounceTime, distinctUntilChanged, switchMap } from 'rxjs/operators';
import { FormBuilder } from "@angular/forms";

@Component({
  selector: "app-banner",
  templateUrl: "./banner.component.html",
  styleUrls: ["./banner.component.scss"]
})
export class BannerComponent implements OnInit {
  @Input() data: any;
  @Input() type: any;
  @Input() title: any;
  @Input() desc: any;
  @ViewChild("searchBox") ss: any;

  items;
  private searchTerms = new Subject<string>();
  filteredUsers: Observable<any>;

  searchForm = this.fb.group({
    userInput: null
  });

  constructor(private dService: DashboardService, private fb: FormBuilder) {}

  ngOnInit(): void {

  }

  search(term: string): void {
    this.dService.search(term.toLowerCase()).subscribe(res => {
      let dup = [];
      res.map(x => {
        dup.push(x.toLowerCase());
      });
      this.items = dup.filter(u => u.includes(term));
    });
  }

  place(item) {
    this.ss.nativeElement.value = item;
    this.items = [];
  }
}
