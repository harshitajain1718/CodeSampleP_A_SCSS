/// <reference types="@types/googlemaps" />
import { Component, OnInit, ViewChild } from '@angular/core';
declare var google: any;

@Component({
  selector: "app-map",
  template: `
    <div #gmap style="width:100%; height:480px"></div>
  `,
  styles: []
})
export class MapComponent implements OnInit {

  @ViewChild("gmap") gmapElement: any;
  map: google.maps.Map;
  geocoder: any;

  constructor() {}

  ngOnInit() {
    var myLatLng = { lat: 23.0128875, lng: 72.5583298 };
    // let options = {
    //   // center: new google.maps.LatLng(51.508742, -0.12085),
    //   center: myLatLng,
    //   zoom: 2,
    //   mapTypeId: google.maps.MapTypeId.ROADMAP
    // };
    // this.map = new google.maps.Map(this.gmapElement.nativeElement, options)
    let address = 'Carrer del Sindicat, 69, 07002 Palma, Illes Balears';
    setTimeout(() => {
      this.geocoder = new google.maps.Geocoder();
      this.geocoder.geocode({address: address}, (results, status) => {
        if(status == google.maps.GeocoderStatus.OK) {
          var latitude = results[0].geometry.location.lat();
          var longitude = results[0].geometry.location.lng();

          var myLatLng = { lat: latitude, lng: longitude };
          
          var map = new google.maps.Map(this.gmapElement.nativeElement, {
            zoom: 4,
            center: myLatLng
          });
          var marker = new google.maps.Marker({
            position: myLatLng,
            map: map,
            title: address
          });
        }
      })
    }, 100)

  }
}
