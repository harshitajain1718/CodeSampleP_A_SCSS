import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, Validators, AbstractControl, FormGroup } from "@angular/forms";
import { DashboardService } from "../services/dashboard.service";
import { ToastrService } from "ngx-toastr";

@Component({
  selector: "app-contact",
  templateUrl: "./contact.component.html",
  styleUrls: ["./contact.component.scss"]
})
export class ContactComponent implements OnInit {

  bannerList = [
    { banner_image: "assets/img/slide-01.jpg" },
    { banner_image: "assets/img/slide-02.jpg" },
    { banner_image: "assets/img/slide-01.jpg" }
  ];
  title = "Contact";
  desc = "Lorem ipsum consectetur adipiscing elitroin<br>viverra vulputate honcus suscipit.";

  @ViewChild('btn') btn: any;
  submitted = false;
  topicList = [];

  contactForm = this.fb.group({
    user_name: ["", Validators.required],
    user_email: ["",
      [Validators.required, Validators.pattern(/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/)]
    ],
    user_policy_number: ["", [Validators.required, Validators.pattern(/^(0|[1-9][0-9]*)$/)]],
    topic: ["", Validators.required],
    message: ["", Validators.required]
  });

  constructor(
    private fb: FormBuilder,
    private dashBoardService: DashboardService,
    private toastr: ToastrService
  ) {}

  get f() {
    return this.contactForm.controls;
  }

  getErrorMessage(control: AbstractControl) {
    if (control.hasError("required")) {
      return "This field is required";
    } else if (control.hasError("pattern")) {
      if (control == this.f.user_policy_number) {
        return "Only numbers are allowed";
      }
      return "Email is invalid";
    }
    return null;
  }

  submit() {
    this.submitted = true;
    if (this.contactForm.invalid) return;
    let data = this.contactForm.value
    this.btn.nativeElement.disabled = true;
    this.dashBoardService.saveContact(data).subscribe((res) => {
      if(res && res['success']) {
        this.submitted = false;
        this.toastr.success('Success!', 'Your Inquiery has been added Successfully');
        this.contactForm.reset()
        this.btn.nativeElement.disabled = false;
      }
    }, (err) => {
      this.btn.nativeElement.disabled = false;
      this.toastr.error('Error!', 'Something went wrong')
      console.log(err);
    })
  }

  ngOnInit() {
    this.dashBoardService.getCategoryList()
      .subscribe((res) => {
        if (res["success"] && res["insuranceData"].length > 0) {
          this.topicList = [...res["insuranceData"]];
        }
      });
  }
}
