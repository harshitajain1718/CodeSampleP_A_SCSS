import { BrowserModule } from '@angular/platform-browser';

import { BrowserAnimationsModule } from "@angular/platform-browser/animations";

import { NgModule } from '@angular/core';
import { HttpClientModule } from "@angular/common/http";
import { ReactiveFormsModule, FormsModule } from "@angular/forms";

import { ToastrModule } from "ngx-toastr";

import { AppRoutingModule } from './app-routing.module';

import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { OwlModule } from 'ngx-owl-carousel';
import { AboutComponent } from './about/about.component';
import { ContactComponent } from './contact/contact.component';
import { PressComponent } from './press/press.component';
import { MapComponent } from './shared/map/map.component';
import { BannerComponent } from './shared/banner/banner.component';
import { PressDetailComponent } from './press-detail/press-detail.component';
import { QuestionsComponent } from './questions/questions.component';
import { ProductListComponent } from './product-list/product-list.component';
import { InsuranceDetailComponent } from './insurance-detail/insurance-detail.component';
import { ProductDetailComponent } from './product-detail/product-detail.component';
import { CarouselModule } from "ngx-owl-carousel-o";
import { FAQComponent } from './faq/faq.component';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    HeaderComponent,
    FooterComponent,
    AboutComponent,
    ContactComponent,
    PressComponent,
    MapComponent,
    BannerComponent,
    PressDetailComponent,
    QuestionsComponent,
    ProductListComponent,
    InsuranceDetailComponent,
    ProductDetailComponent,
    FAQComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    ReactiveFormsModule,
    FormsModule,
    OwlModule,
    CarouselModule,
    BrowserAnimationsModule,
    ToastrModule.forRoot()
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule {}
