import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from "@angular/router";
import { DashboardService } from "../services/dashboard.service";
import { DomSanitizer, SafeHtml, SafeStyle, SafeScript, SafeUrl, SafeResourceUrl } from '@angular/platform-browser';
import { OwlOptions } from "ngx-owl-carousel-o";

@Component({
  selector: "app-press-detail",
  templateUrl: "./press-detail.component.html",
  styleUrls: ["./press-detail.component.scss"]
})
export class PressDetailComponent implements OnInit {
  bannerList = [
    { banner_image: "assets/img/slide-01.jpg" },
    { banner_image: "assets/img/slide-02.jpg" },
    { banner_image: "assets/img/slide-01.jpg" }
  ];
  title = "Press Detail";
  press_id: any;
  press_details;
  long_desc;
  press_image;
  press_title;
  desc;
  pressList;
  removeId: any;
  newId: any;

  constructor(
    private dashboardService: DashboardService,
    private route: ActivatedRoute,
    private sanitizer: DomSanitizer,
    private router: Router
  ) {
  }

  ngOnInit() {
    
    let idd = this.route.snapshot.params["id"];
    this.press_id = atob(idd);
    let id = this.newId ? atob(this.newId) : this.press_id;
    this.press_data(id);

    this.dashboardService.getPressList().subscribe(
      res => {
        if (res["success"] && res["pressData"].length > 0) {
          this.pressList = [...res["pressData"]];
          this.removeId = this.pressList.findIndex(x => {
            return x.id == id;
          });
          this.pressList.splice(this.removeId, 1);
        }
      },
      err => {
        console.log(err);
      }
    );
  }

  press_data(id) {
    this.dashboardService.getPressDetails(id).subscribe(
      res => {
        if (res["success"] && res["pressData"]) {
          this.press_details = res["pressData"];
          this.desc = this.press_details.press_short_description;
          this.press_title = this.press_details.press_title;
          this.long_desc = this.sanitizer.bypassSecurityTrustHtml(
            this.press_details.press_long_description
          );
          this.press_image = this.press_details.press_image;
        }
      },
      err => {
        console.log(err);
      }
    );
  }

  goto_detail(data) {
    let name = data.press_title.replace(/ /g, '-');
    this.newId = btoa(data.id);
    this.router.navigateByUrl(`press-detail/${name}/${this.newId}`)
    this.ngOnInit();
  }

  PressCarouselOptions: OwlOptions = {
    margin: 30,
    nav: true,
    navText: [
      "<div class='nav-btn prev-slide'></div>",
      "<div class='nav-btn next-slide'></div>"
    ],
    // responsiveClass: true,
    dots: false,
    responsive: {
      320: {
        items: 1,
        nav: true
      },
      768: {
        items: 2,
        nav: true
      },
      992: {
        items: 3,
        nav: true,
        loop: true
      }
    }
  };
}
