import { Component, OnInit, NgModule } from '@angular/core';
import { ActivatedRoute, Router } from "@angular/router";
import { DomSanitizer, SafeHtml, SafeStyle, SafeScript, SafeUrl, SafeResourceUrl } from '@angular/platform-browser';
import { DashboardService } from "../services/dashboard.service";
import { ToastrService } from "ngx-toastr";
import { formArrayNameProvider } from '@angular/forms/src/directives/reactive_directives/form_group_name';


@Component({
  selector: 'app-product-detail',
  templateUrl: './product-detail.component.html',
  styleUrls: ['./product-detail.component.scss']
})
export class ProductDetailComponent implements OnInit {
  bannerList = [
    { banner_image: "assets/img/slide-01.jpg" },
    { banner_image: "assets/img/slide-02.jpg" },
    { banner_image: "assets/img/slide-01.jpg" }
  ];
  title = "Product Detail";
  trustedUrl;
  desc;
  video_desc;
  long_desc;
  insurance_id: any;
  removeId:any;
  productDetails;
  productList=[];
  shuffled=[];
  newId:any;
  model: any = {};
  email;
  submitted = false;

  constructor(
    private dashboardService: DashboardService,
    private route: ActivatedRoute,
    private sanitizer: DomSanitizer,
    private router:Router,
    private toastr: ToastrService

  ) { }

  ngOnInit() {

      let idd = this.route.snapshot.params["id"];
      this.insurance_id = atob(idd);
      let id = this.newId ? atob(this.newId) : this.insurance_id;
      this.prod_data(id);

      this.dashboardService.getCategoryList().subscribe((res) => {
        if (res["success"] && res["insuranceData"].length > 0) {
          this.productList = [...res["insuranceData"]];
          this.removeId = this.productList.findIndex((x)=>{
            return x.id == id;
          });
          this.productList.splice(this.removeId,1);
          this.productList.sort(() => 0.5 - Math.random());
        }
      }, (err) => {
        console.log(err);
      })
  }
  onSubmit() {
    this.submitted = true;
     this.dashboardService.newsLetterEmail(this.model.email).subscribe(
       res => {
          if (res["success"]){
            this.toastr.success('You are Successfully Registered as Newsletter Subscription!');
            document.querySelector('form').reset()
          }
       }
     )
  }
  prod_data(id){
    this.dashboardService.getProductDetails(id).subscribe(
      res => {
        if (res["success"] && res["insuranceData"]) {
          this.productDetails = res['insuranceData'];
          this.desc = this.productDetails.short_description;
          this.long_desc = this.sanitizer.bypassSecurityTrustHtml(this.productDetails.long_description);
          this.video_desc = (this.productDetails.video_description != null) ? this.sanitizer.bypassSecurityTrustHtml(this.productDetails.video_description) : null;
          this.trustedUrl = this.sanitizer.bypassSecurityTrustResourceUrl(this.productDetails.insurance_video);
        }
      }, err => {
        console.log(err);
      })
  }
  goto(data){
    let name = data.insurance_title.replace(/ /g, '-');
    this.newId = btoa(data.id);
    this.router.navigateByUrl(`product-detail/${name}/${this.newId}`)
    this.ngOnInit()
  }

  insur_details(data){
    let name = data.insurance_title.replace(/ /g, '-');
    let encid = btoa(data.insurance_id);
    this.router.navigateByUrl(`insurance/${name}/${encid}`)
  }
  
  PressCarouselOptions = {
    margin: 30,
    nav: true,
    navText: [
      "<div class='nav-btn prev-slide'></div>",
      "<div class='nav-btn next-slide'></div>"
    ],
    responsiveClass: true,
    dots: false,
    responsive: {
      320: {
        items: 1,
        nav: true
      },
      768: {
        items: 2,
        nav: true
      },
      992: {
        items: 3,
        nav: true,
        loop: true
      }
    }
  };

}
