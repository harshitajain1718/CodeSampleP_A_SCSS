import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { environment } from "../../environments/environment";
import { map, catchError, filter, tap, find, debounceTime } from "rxjs/operators";
import { Observable, of, throwError } from "rxjs";
import actividades_list from "../../assets/docs/actividades_list.json";

@Injectable({
  providedIn: "root"
})
export class DashboardService {
  url = environment.api.base_url;
  topicsList: any;
  topics: any[] = actividades_list;

  constructor(private http: HttpClient) {}

  getBannerList() {
    return this.http
      .get(`${this.url}/banners/list`)
      .pipe(catchError(this.handleError<any>()));
  }

  getCategoryList() {
    return this.http
      .get(`${this.url}/insurances/list`)
      .pipe(catchError(this.handleError<any>()));
  }
  // ....dhruvika....
  getPressList() {
    return this.http
      .get(`${this.url}/presses/list`)
      .pipe(catchError(this.handleError<any>()));
  }

  getPressDetails(id) {
    return this.http
      .post(`${this.url}/press/detail?press_id=${id}`, "")
      .pipe(catchError(this.handleError<any>()));
  }

  newsLetterEmail(email){
    return this.http
      .post(`${this.url}/news-letter-subscription?email=${email}`, "")
      .pipe(catchError(this.handleError<any>()));
  }

  getFAQList() {
    return this.http
      .get(`${this.url}/faqs/list`)
      .pipe(catchError(this.handleError<any>()));
  }

  getParterList() {
    return this.http
      .get(`${this.url}/partner/list`)
      .pipe(catchError(this.handleError<any>()));
  }
  // ....dhruvika....

  saveContact(data) {
    return this.http
      .post(`${this.url}/contact-inquiery`, data)
      .pipe(catchError(this.handleError<any>()));
  }

  getQuotes() {
    return this.http
      .get(`${this.url}/how-we-work/list`)
      .pipe(catchError(this.handleError<any>()));
  }

  getInsuranceDetails(id) {
    return this.http
      .post(`${this.url}/insurance/detail?insurance_id=${id}`, "")
      .pipe(catchError(this.handleError<any>()));
  }

  search(filter) {
    if(!filter.trim()) {
      return of([]);
    }
    return this.http.get<any>("assets/docs/actividades_list.json").pipe(
      debounceTime(300)
    )
  }

  getProductDetails(id) {
    return this.http
      .post(`${this.url}/insurance/info?insurance_id=${id}`, '')
      .pipe(catchError(this.handleError<any>()));
  }

  handleError<T>(result?: T) {
    return (error: any): Observable<T> => {
      return throwError(error);
    };
  }
}
