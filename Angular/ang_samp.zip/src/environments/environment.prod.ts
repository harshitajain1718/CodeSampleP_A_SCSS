export const environment = {
  production: true,
  api: {
    base_url: "http://devkj.websiteserverhost.com/insurceo_server/public/api",
  }
};
